#define UTS_RELEASE "5.10.0-kali9-arm64"
